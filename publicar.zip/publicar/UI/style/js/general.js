﻿

// ********************  Sesion de Modales con una cantidad de 10 ********************//

$('#myModal1').on('show.bs.modal', function (e) {
    $('.modal .modal-dialog').attr('class', 'modal-dialog fadeInUpBig animated');
})

$('#myModal1').on('hide.bs.modal', function (e) {
    $('.modal .modal-dialog').attr('class', 'modal-dialog fadeOutDownBig animated');
})

$('#myModal2').on('show.bs.modal', function (e) {
    $('.modal .modal-dialog').attr('class', 'modal-dialog fadeInUpBig animated');
})

$('#myModal2').on('hide.bs.modal', function (e) {
    $('.modal .modal-dialog').attr('class', 'modal-dialog fadeOutDownBig animated');
})

$('#myModal3').on('show.bs.modal', function (e) {
    $('.modal .modal-dialog').attr('class', 'modal-dialog fadeInUpBig animated');
})

$('#myModal3').on('hide.bs.modal', function (e) {
    $('.modal .modal-dialog').attr('class', 'modal-dialog fadeOutDownBig animated');
})

$('#myModal4').on('show.bs.modal', function (e) {
    $('.modal .modal-dialog').attr('class', 'modal-dialog fadeInUpBig animated');
})

$('#myModal4').on('hide.bs.modal', function (e) {
    $('.modal .modal-dialog').attr('class', 'modal-dialog fadeOutDownBig animated');
})

$('#myModal5').on('show.bs.modal', function (e) {
    $('.modal .modal-dialog').attr('class', 'modal-dialog fadeInUpBig animated');
})

$('#myModal5').on('hide.bs.modal', function (e) {
    $('.modal .modal-dialog').attr('class', 'modal-dialog fadeOutDownBig animated');
})

$('#myModal6').on('show.bs.modal', function (e) {
    $('.modal .modal-dialog').attr('class', 'modal-dialog fadeInUpBig animated');
})

$('#myModal6').on('hide.bs.modal', function (e) {
    $('.modal .modal-dialog').attr('class', 'modal-dialog fadeOutDownBig animated');
})

$('#myModal7').on('show.bs.modal', function (e) {
    $('.modal .modal-dialog').attr('class', 'modal-dialog fadeInUpBig animated');
})

$('#myModal7').on('hide.bs.modal', function (e) {
    $('.modal .modal-dialog').attr('class', 'modal-dialog fadeOutDownBig animated');
})

$('#myModal8').on('show.bs.modal', function (e) {
    $('.modal .modal-dialog').attr('class', 'modal-dialog fadeInUpBig animated');
})

$('#myModal8').on('hide.bs.modal', function (e) {
    $('.modal .modal-dialog').attr('class', 'modal-dialog fadeOutDownBig animated');
})

$('#myModal9').on('show.bs.modal', function (e) {
    $('.modal .modal-dialog').attr('class', 'modal-dialog fadeInUpBig animated');
})

$('#myModal9').on('hide.bs.modal', function (e) {
    $('.modal .modal-dialog').attr('class', 'modal-dialog fadeOutDownBig animated');
})

$('#myModal10').on('show.bs.modal', function (e) {
    $('.modal .modal-dialog').attr('class', 'modal-dialog fadeInUpBig animated');
})

$('#myModal10').on('hide.bs.modal', function (e) {
    $('.modal .modal-dialog').attr('class', 'modal-dialog fadeOutDownBig animated');
})